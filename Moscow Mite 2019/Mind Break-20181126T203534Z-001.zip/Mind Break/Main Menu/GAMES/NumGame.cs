﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace NumGame
{
    public partial class NumGame : Form
    {
        
        List<int> nums=new List<int>();
        int num = 0;
        
        string code = "";
        bool won=false;
        public NumGame()
        {
            InitializeComponent();
            buttonsNames();
        }

        private void newGameMenu_Click(object sender, EventArgs e)
        {
            File.WriteAllText(".\\FormToOpen.txt", "NumGame");
            File.WriteAllText(".\\isNewGame.txt", "true");
            Application.Restart();
        }

        private void exitGameMenu_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void creatorsMenu_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Създадено от Sybatron");
        }

        void buttonsNames()
        {
            button1.Text = "1";
            button2.Text = "2";
            button3.Text = "3";
            button4.Text = "4";
            button5.Text = "5";
            button6.Text = "6";
            button7.Text = "7";
            button8.Text = "8";
            button9.Text = "9";
            button10.Text = "10";
            button11.Text = "11";
            button12.Text = "12";
            button13.Text = "13";
            button14.Text = "14";
            button15.Text = "15";
            button16.Text = "";
        }

        void checkBottuns(Button botun1, Button botun2)
        {
            if (botun2.Text == "")
            {
                botun2.Text = botun1.Text;
                botun1.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            checkBottuns(button1,button2);
            checkBottuns(button1, button5);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            checkBottuns(button2, button1);
            checkBottuns(button2, button3);
            checkBottuns(button2, button6);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            checkBottuns(button3, button2);
            checkBottuns(button3, button4);
            checkBottuns(button3, button7);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            checkBottuns(button4, button3);
            checkBottuns(button4, button8);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            checkBottuns(button5, button1);
            checkBottuns(button5, button6);
            checkBottuns(button5, button9);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            checkBottuns(button6, button2);
            checkBottuns(button6, button5);
            checkBottuns(button6, button7);
            checkBottuns(button6, button10);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            checkBottuns(button7, button3);
            checkBottuns(button7, button6);
            checkBottuns(button7, button8);
            checkBottuns(button7, button11);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            checkBottuns(button8, button4);
            checkBottuns(button8, button7);
            checkBottuns(button8, button12);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            checkBottuns(button9, button5);
            checkBottuns(button9, button10);
            checkBottuns(button9, button13);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            checkBottuns(button10, button6);
            checkBottuns(button10, button9);
            checkBottuns(button10, button11);
            checkBottuns(button10, button14);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            checkBottuns(button11, button7);
            checkBottuns(button11, button10);
            checkBottuns(button11, button12);
            checkBottuns(button11, button15);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            checkBottuns(button12, button8);
            checkBottuns(button12, button11);
            checkBottuns(button12, button16);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            checkBottuns(button13, button9);
            checkBottuns(button13, button14);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            checkBottuns(button14, button10);
            checkBottuns(button14, button13);
            checkBottuns(button14, button15);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            checkBottuns(button15, button11);
            checkBottuns(button15, button14);
            checkBottuns(button15, button16);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            checkBottuns(button16, button12);
            checkBottuns(button16, button15);
            CheckSolve();
            num++;
            randomLabel.Text = "Clicks: " + num;
        }

        void CheckSolve()
        {
            
            if (button1.Text == "1" && button2.Text == "2" && button3.Text == "3" && button4.Text == "4" &&
                button5.Text == "5" && button6.Text == "6" && button7.Text == "7" && button8.Text == "8" &&
                button9.Text == "9" && button10.Text == "10" && button11.Text == "11" && button12.Text == "12" &&
                button13.Text == "13" && button14.Text == "14" && button15.Text == "15" && button16.Text == "")
            {
                button16.Text = "16";
                unableBotuns();
                randomLabel.Enabled = false;
                MessageBox.Show("Ти победи в "+ num + " хода!!!");
            }
            if (won)
            {
                button16.Text = "16";
                unableBotuns();
                randomLabel.Enabled = false;
                MessageBox.Show("Ти победи в " + num + " хода!!!");
            }
        }
        void unableBotuns()
        {
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button16.Enabled = false;
        }

        public void Shuffle()
        {
            int i = 1, j, Rn;
            int[] a = new int[16];
            Boolean flag = false;
            do
            {
                Random rnd = new Random();
                Rn = Convert.ToInt32((rnd.Next(0, 15)) + 1);
                for (j = 1; j <= i; j++)
                {
                    if (a[j] == Rn)
                    {
                        flag = true;
                        break;
                    }
                }
                if (flag == true)
                {
                    flag = false;
                }
                else
                {
                    a[i] = Rn;
                    i++;
                }
            }
            while (i <= 15);
            button1.Text = Convert.ToString(a[1]);
            button2.Text = Convert.ToString(a[2]);
            button3.Text = Convert.ToString(a[3]);
            button4.Text = Convert.ToString(a[4]);
            button5.Text = Convert.ToString(a[5]);
            button6.Text = Convert.ToString(a[6]);
            button7.Text = Convert.ToString(a[7]);
            button8.Text = Convert.ToString(a[8]);
            button9.Text = Convert.ToString(a[9]);
            button10.Text = Convert.ToString(a[10]);
            button11.Text = Convert.ToString(a[11]);
            button12.Text = Convert.ToString(a[12]);
            button13.Text = Convert.ToString(a[13]);
            button14.Text = Convert.ToString(a[14]);
            button15.Text = Convert.ToString(a[15]);
            button16.Text = "";
            num = 0;
        }

        private void NumGame_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
