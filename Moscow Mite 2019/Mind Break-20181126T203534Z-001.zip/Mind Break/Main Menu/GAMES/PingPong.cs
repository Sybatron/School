﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PingPong
{
    public partial class PingPong : Form
    {
        int playerspeed=30;
        int ballspeed=15;
        int bonus;
        int p1Vel;
        int p2Vel;

        int p1Score = 0;
        int p2Score = 0;

        int bVelX = 5;
        int bVelY = 5;

        bool pause = false;
        string code = "";
        public PingPong()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!pause)
            {
                ball.Location = new Point(ball.Location.X + bVelX, ball.Location.Y + bVelY);
                player1.Location = new Point(player1.Location.X + p1Vel, player1.Location.Y);
                player2.Location = new Point(player2.Location.X + p2Vel, player2.Location.Y);
            }

            if (ball.Location.Y < 0)
            {
                p1Score++; 
                ball.Location = new Point(Width / 2, Height / 2);
            }
            else if (ball.Location.Y > this.Height)
            {
                p2Score++;
                ball.Location = new Point(Width / 2, Height / 2);
            }
            player1Score.Text = p1Score.ToString();
            player2Score.Text = p2Score.ToString();


            if (ball.Location.X < 0)
            {
                bVelX *= -1;
            }
            if (ball.Location.X > Width)
            {
                bVelX *= -1;
            }

            if (ball.Location.X > player2.Location.X &&
                ball.Location.X + ball.Width < player2.Location.X + player2.Width &&
                ball.Location.Y + ball.Height < player2.Location.Y + player2.Height)
            {
                bVelY *= -1;
                bVelX *= -1;
            }
            if (ball.Location.X > player1.Location.X &&
                ball.Location.X + ball.Width < player1.Location.X + player1.Width &&
                ball.Location.Y + ball.Height > player1.Location.Y)
            {
                bVelY *= -1;
            }

            //codeLabel.Text = code.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ball.Location = new Point(Width / 2, Height / 2);
            bVelX = ballspeed;
            bVelY = ballspeed;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                p2Vel = -playerspeed;
            }
            else if (e.KeyCode == Keys.D)
            {
                p2Vel = playerspeed;
            }

            if (e.KeyCode == Keys.Left)
            {
                p1Vel = -playerspeed;
            }
            else if (e.KeyCode == Keys.Right)
            {
                p1Vel = playerspeed;
            }

            if (e.KeyCode == Keys.Space)
            {
                pause = !pause;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                p2Vel = 0;
            }
            if (e.KeyCode == Keys.D)
            {
                p2Vel = 0;
            }
            if (e.KeyCode == Keys.Left)
            {
                p1Vel = 0;
            }
            if (e.KeyCode == Keys.Right)
            {
                p1Vel = 0;
            }

            if (e.KeyCode == Keys.M)
            {
                code = "";
            }
            if (e.KeyCode == Keys.Enter)
            {
                if (code == "KILL")
                {
                    p1Score += 5000;
                }
                code = "";
            }
            if (char.IsLetter((char)e.KeyCode) && e.KeyCode!=Keys.M && e.KeyCode!=Keys.A && e.KeyCode!=Keys.D)
            {
                code += e.KeyCode.ToString();
            }
        }
    }
}
