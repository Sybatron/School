﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class TicTacToe : Form
    {
        bool turn = true;//true = Играч X; false = Играч O;
        int turn_count = 0;
        int secs = 10;

        public TicTacToe()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("От Sybatron", "Морски шах");
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            secs = 10;
            if (turn)
            {
                b.Text = "X";
                playerTurnLabel.Text = "Играч O";
            }
            else
            {
                b.Text = "O";
                playerTurnLabel.Text = "Играч X";
            }
            
            turn = !turn;
            turn_count++;
            b.Enabled = false;
            checkForWinner();
        }

        void checkForWinner()
        {
            //Horizontal check
            if (A1.Text == A2.Text && A1.Text == A3.Text && !A1.Enabled)
            {
                sayTheWinner();
            }
            else if (B1.Text == B2.Text && B1.Text == B3.Text && !B1.Enabled)
            {
                sayTheWinner();
            }
            else if (C1.Text == C2.Text && C1.Text == C3.Text && !C1.Enabled)
            {
                sayTheWinner();
            }

            //Vertical check
            else if (A1.Text == B1.Text && A1.Text == C1.Text && !A1.Enabled)
            {
                sayTheWinner();
            }
            else if (A2.Text == B2.Text && A2.Text == C2.Text && !A2.Enabled)
            {
                sayTheWinner();
            }
            else if (A3.Text == B3.Text && A3.Text == C3.Text && !A3.Enabled)
            {
                sayTheWinner();
            }

            //Diagonal check
            else if (A1.Text == B2.Text && A1.Text == C3.Text && !A1.Enabled)
            {
                sayTheWinner();
            }
            else if (A3.Text == B2.Text && A3.Text == C1.Text && !A3.Enabled)
            {
                sayTheWinner();
            }//End If

            else if (turn_count >= 9)
            {
                MessageBox.Show("Никой не печели!", "Равни!");
            }
        }//End of the checkForWinner

        void sayTheWinner()
        {
            disableButtons();
            timerTurns.Enabled = false;
            string winner="Победителят е ";
            if(turn)
            {
                winner+="Играч O";
            }
            else winner+="Играч X";
            MessageBox.Show(winner, "Победа!");
        }

        void disableButtons()
        {
            try
            {
                foreach (Control c in Controls)
                {
                    Button b = (Button)c;
                    b.Enabled = false;
                }
            }
            catch { }
        }//end of disableButtons

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            turn = true;
            turn_count = 0;
            secs = 10;
            timeLabel.Text = "10 секунди";
            timerTurns.Enabled = true;
            try
            {
                foreach (Control c in Controls)
                {
                    Button b = (Button)c;
                    b.Enabled = true;
                    b.Text = "";
                }
            }
            catch { }
            
        }

        private void timerTurns_Tick(object sender, EventArgs e)
        {
            secs--;
            if (secs <= 0)
            {
                secs = 10;
                turn = !turn;

                if (turn)
                {
                    playerTurnLabel.Text = "Играч X";
                }
                else
                {
                    playerTurnLabel.Text = "Играч O";
                }
            }
            timeLabel.Text=secs.ToString()+" секунди";
        }
    }
}
