﻿namespace Mind_Break
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.CGButton = new System.Windows.Forms.Button();
            this.aboutButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.CGpanel = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.snakeButton = new System.Windows.Forms.Button();
            this.numGameButton = new System.Windows.Forms.Button();
            this.pingpongButton = new System.Windows.Forms.Button();
            this.tictactoeButton = new System.Windows.Forms.Button();
            this.killmoleButton = new System.Windows.Forms.Button();
            this.puzzleButton = new System.Windows.Forms.Button();
            this.hangmanButton = new System.Windows.Forms.Button();
            this.CGScrollBar = new System.Windows.Forms.VScrollBar();
            this.CG_MovablePanel = new System.Windows.Forms.Panel();
            this.CGpanel.SuspendLayout();
            this.CG_MovablePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // CGButton
            // 
            resources.ApplyResources(this.CGButton, "CGButton");
            this.CGButton.Name = "CGButton";
            this.CGButton.UseVisualStyleBackColor = true;
            this.CGButton.Click += new System.EventHandler(this.CGButton_Click);
            this.CGButton.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.CGButton.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // aboutButton
            // 
            resources.ApplyResources(this.aboutButton, "aboutButton");
            this.aboutButton.Name = "aboutButton";
            this.aboutButton.UseVisualStyleBackColor = true;
            this.aboutButton.Click += new System.EventHandler(this.aboutButton_Click);
            this.aboutButton.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.aboutButton.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // exitButton
            // 
            resources.ApplyResources(this.exitButton, "exitButton");
            this.exitButton.Name = "exitButton";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            this.exitButton.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.exitButton.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // CGpanel
            // 
            this.CGpanel.Controls.Add(this.button11);
            this.CGpanel.Controls.Add(this.snakeButton);
            this.CGpanel.Controls.Add(this.numGameButton);
            this.CGpanel.Controls.Add(this.pingpongButton);
            this.CGpanel.Controls.Add(this.tictactoeButton);
            this.CGpanel.Controls.Add(this.killmoleButton);
            this.CGpanel.Controls.Add(this.puzzleButton);
            this.CGpanel.Controls.Add(this.hangmanButton);
            resources.ApplyResources(this.CGpanel, "CGpanel");
            this.CGpanel.Name = "CGpanel";
            // 
            // button11
            // 
            resources.ApplyResources(this.button11, "button11");
            this.button11.Name = "button11";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.button11.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // snakeButton
            // 
            resources.ApplyResources(this.snakeButton, "snakeButton");
            this.snakeButton.Name = "snakeButton";
            this.snakeButton.UseVisualStyleBackColor = true;
            this.snakeButton.Click += new System.EventHandler(this.snakeButton_Click);
            this.snakeButton.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.snakeButton.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // numGameButton
            // 
            resources.ApplyResources(this.numGameButton, "numGameButton");
            this.numGameButton.Name = "numGameButton";
            this.numGameButton.UseVisualStyleBackColor = true;
            this.numGameButton.Click += new System.EventHandler(this.numGameButton_Click);
            this.numGameButton.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.numGameButton.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // pingpongButton
            // 
            resources.ApplyResources(this.pingpongButton, "pingpongButton");
            this.pingpongButton.Name = "pingpongButton";
            this.pingpongButton.UseVisualStyleBackColor = true;
            this.pingpongButton.Click += new System.EventHandler(this.pingpongButton_Click);
            this.pingpongButton.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.pingpongButton.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // tictactoeButton
            // 
            resources.ApplyResources(this.tictactoeButton, "tictactoeButton");
            this.tictactoeButton.Name = "tictactoeButton";
            this.tictactoeButton.UseVisualStyleBackColor = true;
            this.tictactoeButton.Click += new System.EventHandler(this.tictactoeButton_Click);
            this.tictactoeButton.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.tictactoeButton.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // killmoleButton
            // 
            resources.ApplyResources(this.killmoleButton, "killmoleButton");
            this.killmoleButton.Name = "killmoleButton";
            this.killmoleButton.UseVisualStyleBackColor = true;
            this.killmoleButton.Click += new System.EventHandler(this.killmoleButton_Click);
            this.killmoleButton.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.killmoleButton.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // puzzleButton
            // 
            resources.ApplyResources(this.puzzleButton, "puzzleButton");
            this.puzzleButton.Name = "puzzleButton";
            this.puzzleButton.UseVisualStyleBackColor = true;
            this.puzzleButton.Click += new System.EventHandler(this.puzzleButton_Click);
            this.puzzleButton.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.puzzleButton.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // hangmanButton
            // 
            resources.ApplyResources(this.hangmanButton, "hangmanButton");
            this.hangmanButton.Name = "hangmanButton";
            this.hangmanButton.UseVisualStyleBackColor = true;
            this.hangmanButton.Click += new System.EventHandler(this.hangmanButton_Click);
            this.hangmanButton.MouseEnter += new System.EventHandler(this.onMouseColor_MouseEnter);
            this.hangmanButton.MouseLeave += new System.EventHandler(this.normalColor_MouseLeave);
            // 
            // CGScrollBar
            // 
            resources.ApplyResources(this.CGScrollBar, "CGScrollBar");
            this.CGScrollBar.Maximum = 120;
            this.CGScrollBar.Name = "CGScrollBar";
            this.CGScrollBar.SmallChange = 10;
            this.CGScrollBar.ValueChanged += new System.EventHandler(this.CGScrollBar_ValueChanged);
            // 
            // CG_MovablePanel
            // 
            this.CG_MovablePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CG_MovablePanel.Controls.Add(this.CGpanel);
            this.CG_MovablePanel.Controls.Add(this.CGScrollBar);
            resources.ApplyResources(this.CG_MovablePanel, "CG_MovablePanel");
            this.CG_MovablePanel.Name = "CG_MovablePanel";
            // 
            // MainMenu
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Controls.Add(this.CG_MovablePanel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.aboutButton);
            this.Controls.Add(this.CGButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MainMenu";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainMenu_FormClosed);
            this.Load += new System.EventHandler(this.MainMenu_Load);
            this.Shown += new System.EventHandler(this.MainMenu_Shown);
            this.CGpanel.ResumeLayout(false);
            this.CG_MovablePanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CGButton;
        private System.Windows.Forms.Button aboutButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Panel CGpanel;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button snakeButton;
        private System.Windows.Forms.Button numGameButton;
        private System.Windows.Forms.Button pingpongButton;
        private System.Windows.Forms.Button tictactoeButton;
        private System.Windows.Forms.Button killmoleButton;
        private System.Windows.Forms.Button puzzleButton;
        private System.Windows.Forms.Button hangmanButton;
        private System.Windows.Forms.VScrollBar CGScrollBar;
        private System.Windows.Forms.Panel CG_MovablePanel;
    }
}

