﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Mind_Break.Main_Menu
{
    public partial class StartOver : Form
    {
        public StartOver()
        {
            InitializeComponent();
        }

        private void Refresh_Load(object sender, EventArgs e)
        {

        }
    }
}
